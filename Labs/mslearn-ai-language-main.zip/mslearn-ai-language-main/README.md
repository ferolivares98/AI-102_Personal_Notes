# mslearn-ai-language
Lab files for Azure AI Language modules
