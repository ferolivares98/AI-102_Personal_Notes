# mslearn-document-intelligence
Lab files for Azure AI Document Intelligence modules
